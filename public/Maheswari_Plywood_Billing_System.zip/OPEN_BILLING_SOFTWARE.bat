@echo off
start "" "%~dp0Maheswari_Plywood_Billing_Software.html"
