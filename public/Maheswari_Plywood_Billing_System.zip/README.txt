MAHESWARI PLYWOOD & HARDWARE - BILLING & INVENTORY SYSTEM (v2.0)
=================================================================

FOLDER STRUCTURE:
1. frontend/  --> Complete React 19 + TypeScript + Tailwind CSS Frontend application
2. backend/   --> Complete Node.js + Express REST API Server & JSON Database engine
3. Maheswari_Plywood_Billing_Software.html --> Standalone 1-click offline application
