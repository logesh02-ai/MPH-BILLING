@echo off
echo Starting Maheswari Plywood Backend & Frontend...
start cmd /k "cd backend && npm install && npm run dev"
start cmd /k "cd frontend && npm install && npm run dev"
